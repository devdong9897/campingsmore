import styled from "@emotion/styled";

export const AboutWrapper = styled.div`
  padding-top: 150px;
  width: 100%;
  height: 3000px;
`;
