// import KakaoLogin from "react-kakao-login";

// const SnsKakao = () => {
//   const kakaoClientId = "13e391cae7ce39976c861f8375f44c18";
//   const kakaoOnSuccess = async data => {
//     console.log(data);
//     const idToken = data.response.access_token;
//     const reToken = data.response.refresh_token;
//     console.log("데이터", idToken, reToken);
//   };
//   const kakaoOnFailure = error => {
//     console.log(error);
//   };
//   return (
//     <>
//       <KakaoLogin
//         token={kakaoClientId}
//         onSuccess={kakaoOnSuccess}
//         onFail={kakaoOnFailure}
//       />
//     </>
//   );
// };

// export default SnsKakao;
