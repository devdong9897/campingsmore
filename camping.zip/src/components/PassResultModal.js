import React from 'react'

const PassResultModal = () => {
  return (
    <div>PassResultModal</div>
  )
}

export default PassResultModal