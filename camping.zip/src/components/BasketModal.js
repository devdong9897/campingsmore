import React from "react";

const BasketModal = () => {
  return 
  <div>
    
  </div>;
};

export default BasketModal;
