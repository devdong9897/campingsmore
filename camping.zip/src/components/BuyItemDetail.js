import React from "react";

const BuyItemDetail = () => {
  return <div>BuyItemDetail</div>;
};

export default BuyItemDetail;
