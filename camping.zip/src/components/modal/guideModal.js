import React from 'react'

const guideModal = () => {
  return (
    <div>guideModal</div>
  )
}

export default guideModal