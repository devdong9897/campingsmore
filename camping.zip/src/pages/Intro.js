import React from "react";

const Intro = () => {
  return <div>intro</div>;
};

export default Intro;
