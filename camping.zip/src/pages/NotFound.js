import React from "react";

const NotFound = () => {
  return <div>NotFound
    dddd
  </div>;
};

export default NotFound;
