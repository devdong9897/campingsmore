import React from "react";
import { AboutWrapper } from "../css/about-style";

const About = () => {
  return (
    <AboutWrapper>
      <div className="inner"></div>
    </AboutWrapper>
  );
};

export default About;
